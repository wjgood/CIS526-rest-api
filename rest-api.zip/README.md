To launch the server:

`npm start`

To test the server:

`npm test`

Note: You also need to install the test support libraries, with:

`npm install`
